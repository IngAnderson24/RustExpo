use std::str::FromStr;

fn main() {
    println!("Ingrese el número: ");
    let mut num: i64 = leer_numero();
    let mut signo: i32 = 1;
    let mut suma_a = 0;
    let mut suma_b = 0;
    while num > 0 {
        if signo == 1{
            suma_a += num%10; 
        } else{
            suma_b += num%10;
        }
        num /= 10;
        signo *= -1;
    }
    let divisible; 
    if (suma_a - suma_b).abs() % 11 == 0{
        divisible = "SI";
    }
    else{
        divisible = "NO";
    }
    println!("{1} divisible por 11{2}: {0}", divisible, "¿El número que ingresaste es", "?");
}

fn leer_entrada() -> String {
    let mut input = String::new();
    std::io::stdin().read_line( &mut input).expect("¿?");
    input.trim().to_string()
}

fn leer_numero() -> i64 {
    let input = leer_entrada();
    i64::from_str(&input).expect("Error, usted no ha ingresado un número.")
}